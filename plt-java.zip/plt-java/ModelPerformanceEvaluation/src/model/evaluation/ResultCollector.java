package model.evaluation;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ResultCollector {
	
	public static String DELIMITER = "|";

	private ArrayList<Result> results;
	
	private String label;
	private String etime;
	private String technique;

	private double r;
	private double maxMRE;
	private double MMRE;
	private double pred1;
	private double pred2;
	private double sumARE;
	private double medARE;
	private double SDARE;
	private double RMSE;
	private double NRMSE;
	private double relativeAbsError;
	private double relativeAbsErrorSquare;

	
	public ResultCollector(String label, String etime, String technique) {
		super();
		results = new ArrayList<Result>();
		this.label = label;
		this.etime = etime;
		this.technique = technique;
		r = 0;
		maxMRE = 0;
		MMRE = 0;
		pred1 = 0;
		pred2 = 0;
		sumARE = 0;
		medARE = 0;
		SDARE = 0;
		RMSE = 0;
		NRMSE = 0;
		relativeAbsError = 0;
		relativeAbsErrorSquare = 0;
	}

	public void addResult(Result result) {
		results.add(result);
	}
	
	public String collateResults() {

		StringBuffer sb = new StringBuffer(128);
		DecimalFormat df = new DecimalFormat("###.##");

		for(Result result:results) {
			r += result.getR();
			maxMRE += result.getMaxMRE();
			MMRE += result.getMMRE();
			pred1 += result.getPred1();
			pred2 += result.getPred2();
			sumARE += result.getSumARE();
			medARE += result.getMedARE();
			SDARE += result.getSDARE();
			RMSE += result.getRMSE();
			NRMSE += result.getNRMSE();
			relativeAbsError += result.getRelativeAbsError();
			relativeAbsErrorSquare += result.getRelativeAbsErrorSquare();
		}

		long n = results.size();
		
		//mean of all sets
		r = r/n;
		maxMRE = maxMRE/n;
		MMRE = MMRE/n;
		pred1 = pred1/n;
		pred2 = pred2/n;
		sumARE = sumARE/n;
		medARE = medARE/n;
		SDARE = SDARE/n;
		RMSE = RMSE/n;
		NRMSE = NRMSE/n;
		relativeAbsError = relativeAbsError/n;
		relativeAbsErrorSquare = relativeAbsErrorSquare/n;	
		
		sb.append(label);
		sb.append(DELIMITER);
		sb.append(technique);
		sb.append(DELIMITER);
		sb.append(n);
		sb.append(DELIMITER);
		sb.append(etime);
		sb.append(DELIMITER);
		sb.append(df.format(r));
		sb.append(DELIMITER);
		sb.append(df.format(maxMRE));
		sb.append(DELIMITER);
		sb.append(df.format(MMRE));
		sb.append(DELIMITER);
		sb.append(df.format(pred1));
		sb.append(DELIMITER);
		sb.append(df.format(pred2));
		sb.append(DELIMITER);
		sb.append(df.format(sumARE));
		sb.append(DELIMITER);
		sb.append(df.format(medARE));
		sb.append(DELIMITER);
		sb.append(df.format(SDARE));
		sb.append(DELIMITER);
		sb.append(df.format(RMSE));
		sb.append(DELIMITER);
		sb.append(df.format(NRMSE));
		sb.append(DELIMITER);
		sb.append(df.format(relativeAbsError));
		sb.append(DELIMITER);
		sb.append(df.format(relativeAbsErrorSquare));
		sb.append(DELIMITER);
		
		System.out.println(sb.toString());

		return sb.toString();
	}
	
}
