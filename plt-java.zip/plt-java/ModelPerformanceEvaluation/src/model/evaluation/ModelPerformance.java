package model.evaluation;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;

import model.evaluation.beans.ObsExpDataBean;

public class ModelPerformance {

	public static String DELIMITER = "|";
	
	private static String inputFilePath1;
	private static String inputFilePath2;	
	private static String outputFilePath;
	private static String append;
	private static String debug;
	private static String pred1;
	private static String pred2;
	private static String label;
	private static String etime;
	private static String technique;
	private static String avgOfStatistics;
	
	public static void main(String[] args) {
		
		Options options = new Options();
		
		Option inputOpt1 = new Option("i1", "input1", true, "Input file path");
		inputOpt1.setRequired(true);
		options.addOption(inputOpt1);

		Option inputOpt2 = new Option("i2", "input2", true, "ZeroR file path");
		inputOpt2.setRequired(true);
		options.addOption(inputOpt2);
		
		Option outputOpt = new Option("o", "output", true, "Output file path");
		outputOpt.setRequired(true);
		options.addOption(outputOpt);
		
		Option pred1Opt = new Option("p1", "pred1", true, "pred1");
		pred1Opt.setRequired(true);
		options.addOption(pred1Opt);

		Option pred2Opt = new Option("p2", "pred2", true, "pred2");
		pred2Opt.setRequired(true);
		options.addOption(pred2Opt);
		
		Option modeOpt  = new Option("a", "append", true, "true or false");
		modeOpt.setRequired(true);
		options.addOption(modeOpt);
		
		Option labelOpt = new Option("l", "label", true, "label to add with output");
		labelOpt.setRequired(true);
		options.addOption(labelOpt);

		Option executionTmOpt = new Option("t", "etime", true, "execution time");
		executionTmOpt.setRequired(true);
		options.addOption(executionTmOpt);
		
		Option debugOpt = new Option("d", "debug", true, "true or false");
		debugOpt.setRequired(true);
		options.addOption(debugOpt);
		
		Option techniqueOpt = new Option("q", "technique", true, "learning technique");
		techniqueOpt.setRequired(true);
		options.addOption(techniqueOpt);

		Option avgOfStatisticsOpt = new Option("v", "avg", true, "average of k-fold statistics");
		avgOfStatisticsOpt.setRequired(true);
		options.addOption(avgOfStatisticsOpt);
		
		CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();

        try {
            CommandLine cmd;
            cmd = parser.parse(options, args);
            
            inputFilePath1 = cmd.getOptionValue("input1");
            inputFilePath2 = cmd.getOptionValue("input2");
            outputFilePath = cmd.getOptionValue("output");
            pred1 = cmd.getOptionValue("pred1");
            pred2 = cmd.getOptionValue("pred2");
            append = cmd.getOptionValue("append");
            label = cmd.getOptionValue("label");
            etime = cmd.getOptionValue("etime");
            debug  = cmd.getOptionValue("debug");
            technique = cmd.getOptionValue("technique");
            avgOfStatistics = cmd.getOptionValue("avg");
            
            System.out.println("Starting to process");
            System.out.println(inputFilePath1);
            System.out.println(inputFilePath2);
            System.out.println(outputFilePath);
            System.out.println(pred1);
            System.out.println(pred2);
            System.out.println(append);
            System.out.println(label);
            System.out.println(etime);
            System.out.println(debug);
            System.out.println(technique);
            System.out.println(avgOfStatistics);

            ResultCollector rc = new ResultCollector(label, etime, technique);
    		ObsExpDataReader oedr = new ObsExpDataReader();
    		ArrayList<ArrayList<ObsExpDataBean>> logentriesarr1;
			logentriesarr1 = oedr.read(inputFilePath1, debug, avgOfStatistics);
			
			if (logentriesarr1 == null) {
				return;
			}

    		ArrayList<ArrayList<ObsExpDataBean>> logentriesarr2;
			logentriesarr2 = oedr.read(inputFilePath2, debug, avgOfStatistics);
			
			if (logentriesarr2 == null) {
				return;
			}
			
			for (int i = 0; i < logentriesarr1.size(); i++) {
				ArrayList<ObsExpDataBean> le1 = logentriesarr1.get(i);
				ArrayList<ObsExpDataBean> le2 = logentriesarr2.get(i);
				for (int j = 0; j < le1.size(); j++) {
					le1.get(j).setAbsoluteResidualErrorComparedToBaseline1(le2.get(j).getExp());
					//System.out.println(le1.get(j).getObs() + "," + le1.get(j).getExp() + "," + le2.get(j).getExp());			
				}
			}
        
        
			
			for(ArrayList<ObsExpDataBean> le:logentriesarr1) {
				//System.out.println("New set got = " + le.size());
				Result result = process(le);
				//result.toString();
				rc.addResult(result);
			}

			BufferedWriter bw = null;
			FileWriter fw = null;
			String resultstr;
			resultstr = rc.collateResults();;

			try {
				if (append.equals("false") == true) {
					fw = new FileWriter(outputFilePath);
				} else {
					fw = new FileWriter(outputFilePath, true);
				}
				bw = new BufferedWriter(fw);
				bw.write(avgOfStatistics + ResultCollector.DELIMITER + resultstr);
				bw.write("\n");
				bw.close();
				fw.close();
			} catch (IOException ioe) {
				System.out.println("IOException " + ioe.getMessage());
			} finally {
				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();					
			}
        } catch (ParseException pe) {
            System.out.println(pe.getMessage());
            formatter.printHelp("utility-name", options);
        } catch (Exception e) {
			e.printStackTrace();
            System.out.println("Exception " + e.getMessage());
        } 
	        
	}

		public static Result process(List<ObsExpDataBean> logentries){
		
	    //mean absolute residual error MARE mean(ae)
		//median absolute residual error MedARE  median(ae)
		//standard deviation absolute residual error StdARE  stdev(ae)
		//mean magnitude relative error MMRE mean(mre)
		//median magnitude relative error MedMRE median(mre)
		//standard deviation magnitude relative error StdMRE stdev(mre)
		//rmse
		//pred1
		//pred2
		//relative absolute error (rae)
		//relative squared error (rse)

        double p1 = Double.parseDouble(pred1);
        double p2 = Double.parseDouble(pred2);
		
		double[] absoluteResidualErrorArray  = new double[logentries.size()];
		double[] magnitudeRelativeErrorArray = new double[logentries.size()];
		double[] obsArray = new double[logentries.size()];
		double[] expArray = new double[logentries.size()];
		double   sumOfsquareOfResidualError = 0;
		
		int i = 0;
		for(ObsExpDataBean le:logentries) {
			absoluteResidualErrorArray[i]  = le.getAbsoluteResidualError();
			magnitudeRelativeErrorArray[i] = le.getMagnitudeRelativeError();
			sumOfsquareOfResidualError     = sumOfsquareOfResidualError + le.getSquareOfResidualError();
			obsArray[i] = le.getObs();
			expArray[i] = le.getExp();

			if (magnitudeRelativeErrorArray[i] > 50) {
				System.out.println(le.getExp() + "," + le.getObs());
			}
			i++;
		}

		DescriptiveStatistics obsStats  = new DescriptiveStatistics();
		for (i = 0; i < obsArray.length; i++){
			obsStats.addValue(obsArray[i]);
		}
	
		DescriptiveStatistics absoluteResidualErrorStats  = new DescriptiveStatistics();
		for (i = 0; i < absoluteResidualErrorArray.length; i++){
			absoluteResidualErrorStats.addValue(absoluteResidualErrorArray[i]);
		}

		DescriptiveStatistics magnitudeRelativeErrorStats = new DescriptiveStatistics();
		for (i = 0; i < magnitudeRelativeErrorArray.length; i++){
			magnitudeRelativeErrorStats.addValue(magnitudeRelativeErrorArray[i]);
		}

		long   n      = magnitudeRelativeErrorStats.getN();
		double maxMRE = magnitudeRelativeErrorStats.getMax();
		double MMRE   = magnitudeRelativeErrorStats.getMean();
		double sumARE = absoluteResidualErrorStats.getSum();
		double medARE = absoluteResidualErrorStats.getPercentile(50);
		double SDARE  = absoluteResidualErrorStats.getStandardDeviation();
		double RMSE   = Math.sqrt(sumOfsquareOfResidualError/n);
		double meanObs= obsStats.getMean();
		double minObs = obsStats.getMin();
		double maxObs = obsStats.getMax();
		double k1, k2;

		
		System.out.println("max obs" + maxMRE);
		k1 = 0;
		k2 = 0;
		for (i = 0; i < magnitudeRelativeErrorArray.length; i++) {
			if (magnitudeRelativeErrorArray[i] <= p1) {
				k1++;
			}
			if (magnitudeRelativeErrorArray[i] <= p2) {
				k2++;
			}
		}

		double pred1 = k1/n;
		double pred2 = k2/n;

		double   sumOfabsoluteResidualErrorComparedToBaseline1  = 0;
		double   sumOfsquareOfabsoluteResidualErrorComparedToBaseline1 = 0;
		
		for(ObsExpDataBean le:logentries) {
			//le.setAbsoluteResidualErrorComparedToBaseline1(meanObs);
			//System.out.println(le.getAbsoluteResidualErrorComparedToBasic() + "|" + 
			//le.getSquareOfabsoluteResidualErrorComparedToBasic());
			sumOfabsoluteResidualErrorComparedToBaseline1  = sumOfabsoluteResidualErrorComparedToBaseline1 
					+ le.getAbsoluteResidualErrorComparedToBaseline1();
			sumOfsquareOfabsoluteResidualErrorComparedToBaseline1 = sumOfsquareOfabsoluteResidualErrorComparedToBaseline1 
					+ le.getSquareOfabsoluteResidualErrorComparedToBaseline1();
		}
		
		double relativeAbsError       = sumARE/sumOfabsoluteResidualErrorComparedToBaseline1;
		double relativeAbsErrorSquare = Math.sqrt(sumOfsquareOfResidualError/sumOfsquareOfabsoluteResidualErrorComparedToBaseline1);
		double NRMSE = RMSE/(maxObs - minObs);
		double r = new PearsonsCorrelation().correlation(obsArray, expArray);
		if (Double.isNaN(r) == true) {
			r = 0;
		}
		
		return new Result(label, technique, n, etime, r, maxMRE, MMRE, pred1, pred2, sumARE, medARE,
				SDARE, RMSE, NRMSE, relativeAbsError, relativeAbsErrorSquare);
		
		}
}
