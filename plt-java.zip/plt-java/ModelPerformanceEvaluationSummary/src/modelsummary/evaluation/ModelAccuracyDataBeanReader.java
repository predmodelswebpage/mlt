package modelsummary.evaluation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import modelsummary.evaluation.beans.ModelAccuracyDataBean;

public class ModelAccuracyDataBeanReader {

	public List<ModelAccuracyDataBean> read(String filename, String debug) throws Exception {
		
		List<ModelAccuracyDataBean> logentries = new ArrayList<ModelAccuracyDataBean>();
		
		FileReader fr = new FileReader(filename);
		try {
			Iterable<CSVRecord> records = CSVFormat.RFC4180.withIgnoreEmptyLines().withDelimiter('|').parse(fr);
			for (CSVRecord record : records) {
				String label = record.get(ModelAccuracyDataBean.LABEL);
				String technique = record.get(ModelAccuracyDataBean.TECHNIQUE);
				String etime = record.get(ModelAccuracyDataBean.ETIME);
				String correlation = record.get(ModelAccuracyDataBean.CORRELATION);
				String maxMagnitudeRelativeError = record.get(ModelAccuracyDataBean.MAXMAGNITUDERELATIVEERROR);
				String meanMagnitudeRelativeError = record.get(ModelAccuracyDataBean.MEANMAGNITUDERELATIVEERROR);
				String pred1 = record.get(ModelAccuracyDataBean.PRED1);
				String pred2 = record.get(ModelAccuracyDataBean.PRED2);
				String sumAbsoluteResidualError = record.get(ModelAccuracyDataBean.SUMABSOLUTERESIDUALERROR);
				String medianAbsoluteResidualError = record.get(ModelAccuracyDataBean.MEDIANABSOLUTERESIDUALERROR);
				String stdevAbsoluteResidualError = record.get(ModelAccuracyDataBean.STDEVABSOLUTERESIDUALERROR);
				String rmse = record.get(ModelAccuracyDataBean.RMSE);
				String nrmse = record.get(ModelAccuracyDataBean.NRMSE);
				String relativeAbsoluteError = record.get(ModelAccuracyDataBean.RELATIVEABSOLUTEERROR);
				String rootOfrelativeSquareError = record.get(ModelAccuracyDataBean.ROOTOFRELATIVESQUAREERROR);
				
			    ModelAccuracyDataBean oedb = new ModelAccuracyDataBean(label, technique,
			    		Integer.parseInt(etime), 
			    		Double.parseDouble(correlation),
			    		Double.parseDouble(maxMagnitudeRelativeError),
			    		Double.parseDouble(meanMagnitudeRelativeError), 
			    		Double.parseDouble(pred1), 
			    		Double.parseDouble(pred2), 
			    		Double.parseDouble(sumAbsoluteResidualError),
			    		Double.parseDouble(medianAbsoluteResidualError), 
			    		Double.parseDouble(stdevAbsoluteResidualError), 
			    		Double.parseDouble(rmse), 
			    		Double.parseDouble(nrmse),
			    		Double.parseDouble(relativeAbsoluteError), 
			    		Double.parseDouble(rootOfrelativeSquareError)); 

				if (debug.equals("true") == true) {
				    System.out.println(oedb.toString());
				}

				logentries.add(oedb);
			}
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
			fr.close();
			return null;
		}


		return logentries;
	}
}
