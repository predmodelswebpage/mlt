package modelsummary.evaluation;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import modelsummary.evaluation.beans.ModelAccuracyDataBean;
import modelsummary.evaluation.beans.ModelAccuracySummaryBean;

public class ModelAccuracy {

	public static final String DELIMITER = "|";
	public static final int    BLOCKSIZE = 19; //1


	private static String inputFilePath;
	private static String outputFilePath;
	private static String append;
	private static String debug;
	
	public static void main(String[] args) {
		
		Options options = new Options();
		
		Option inputOpt = new Option("i", "input", true, "input file path");
		inputOpt.setRequired(true);
		options.addOption(inputOpt);
		
		Option outputOpt = new Option("o", "output", true, "output file path");
		outputOpt.setRequired(true);
		options.addOption(outputOpt);
		
		Option modeOpt = new Option("a", "append", true, "true or false");
		modeOpt.setRequired(true);
		options.addOption(modeOpt);

		Option debugOpt = new Option("d", "debug", true, "true or false");
		debugOpt.setRequired(true);
		options.addOption(debugOpt);
		
		CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();

        try {
            CommandLine cmd;
            cmd = parser.parse(options, args);
            
            inputFilePath = cmd.getOptionValue("input");
            outputFilePath = cmd.getOptionValue("output");
            append = cmd.getOptionValue("append");
            debug  = cmd.getOptionValue("debug");
            
            
            System.out.println(inputFilePath);
            System.out.println(outputFilePath);
            System.out.println(append);
            System.out.println(debug);
            
            ModelAccuracyDataBeanReader oedr = new ModelAccuracyDataBeanReader();
    		List<ModelAccuracyDataBean> logentries;
			logentries = oedr.read(inputFilePath, debug);
			if (logentries != null) {
				process(logentries);
			}
			
			System.out.println("Processing complete....");
			
        } catch (ParseException pe) {
            System.out.println(pe.getMessage());
            formatter.printHelp("utility-name", options);
        } catch (Exception e) {
			e.printStackTrace();
            System.out.println("Exception " + e.getMessage());
        } 
	        
	}

	public static void process(List<ModelAccuracyDataBean> logentries) {

		BufferedWriter bw = null;
		FileWriter fw = null;
		ModelAccuracySummaryBean modelAccuracySummaryBean = new ModelAccuracySummaryBean();
		int count = 0;
		
		try {
			if (append.equals("false") == true) {
				fw = new FileWriter(outputFilePath);
			} else {
				fw = new FileWriter(outputFilePath, true);
			}
			bw = new BufferedWriter(fw);
			
			for(ModelAccuracyDataBean le:logentries) {
				if (count%BLOCKSIZE == 0) {
					
					if (count != 0) {
						if (debug.equals("true") == true) {
							System.out.println(modelAccuracySummaryBean.toString());
						}
						bw.write(modelAccuracySummaryBean.toString());
						bw.write("\n");
					}
					
					modelAccuracySummaryBean.setLabel(le.getLabel());
					
					//0
					modelAccuracySummaryBean.setCorrelation(le.getCorrelation());
					modelAccuracySummaryBean.setCorrelationTechnique(le.getTechnique());
					
					//1
					modelAccuracySummaryBean.setMaxMagnitudeRelativeError(le.getMaxMagnitudeRelativeError());
					modelAccuracySummaryBean.setMaxMagnitudeRelativeErrorTechnique(le.getTechnique());
					
					//2
					modelAccuracySummaryBean.setMeanMagnitudeRelativeError(le.getMeanMagnitudeRelativeError());
					modelAccuracySummaryBean.setMeanMagnitudeRelativeErrorTechnique(le.getTechnique());
	
					//3
					modelAccuracySummaryBean.setPred1(le.getPred1());
					modelAccuracySummaryBean.setPred1Technique(le.getTechnique());
					
					//4
					modelAccuracySummaryBean.setPred2(le.getPred2());
					modelAccuracySummaryBean.setPred2Technique(le.getTechnique());
					
					//5
					modelAccuracySummaryBean.setSumAbsoluteResidualError(le.getSumAbsoluteResidualError());
					modelAccuracySummaryBean.setSumAbsoluteResidualErrorTechnique(le.getTechnique());	
					
					//6
					modelAccuracySummaryBean.setMedianAbsoluteResidualError(le.getMedianAbsoluteResidualError());
					modelAccuracySummaryBean.setMedianAbsoluteResidualErrorTechnique(le.getTechnique());
					
					//7
					modelAccuracySummaryBean.setStdevAbsoluteResidualError(le.getStdevAbsoluteResidualError());
					modelAccuracySummaryBean.setStdevAbsoluteResidualErrorTechnique(le.getTechnique());
					
					//8
					modelAccuracySummaryBean.setRmse(le.getRmse());
					modelAccuracySummaryBean.setRmseTechnique(le.getTechnique());
					
					//9
					modelAccuracySummaryBean.setNrmse(le.getNrmse());
					modelAccuracySummaryBean.setNrmseTechnique(le.getTechnique());
					
					//10
					modelAccuracySummaryBean.setRelativeAbsoluteError(le.getRelativeAbsoluteError());
					modelAccuracySummaryBean.setRelativeAbsoluteErrorTechnique(le.getTechnique());
					
					//11
					modelAccuracySummaryBean.setRootOfrelativeSquareError(le.getRootOfrelativeSquareError());
					modelAccuracySummaryBean.setRootOfrelativeSquareErrorTechnique(le.getTechnique());
					
					System.out.println(modelAccuracySummaryBean.getRootOfrelativeSquareErrorTechnique());
				} else {

					System.out.println(modelAccuracySummaryBean.getRootOfrelativeSquareErrorTechnique());
					
					//0, more the better
					if (le.getCorrelation() > modelAccuracySummaryBean.getCorrelation()) {
						modelAccuracySummaryBean.setCorrelationTechnique(le.getTechnique());
						modelAccuracySummaryBean.setCorrelation(le.getCorrelation());
					} else if (le.getCorrelation() == modelAccuracySummaryBean.getCorrelation()) {
						modelAccuracySummaryBean.setCorrelationTechnique(
								modelAccuracySummaryBean.getCorrelationTechnique() + ":" +
								le.getTechnique());
					}
					
					//1, less the better
					if (le.getMaxMagnitudeRelativeError() < modelAccuracySummaryBean.getMaxMagnitudeRelativeError()) {
						modelAccuracySummaryBean.setMaxMagnitudeRelativeErrorTechnique(le.getTechnique());
						modelAccuracySummaryBean.setMaxMagnitudeRelativeError(le.getMaxMagnitudeRelativeError());
					}
					
					//2, less the better
					if (le.getMeanMagnitudeRelativeError() < modelAccuracySummaryBean.getMeanMagnitudeRelativeError()) {
						modelAccuracySummaryBean.setMeanMagnitudeRelativeErrorTechnique(le.getTechnique());
						modelAccuracySummaryBean.setMeanMagnitudeRelativeError(le.getMeanMagnitudeRelativeError());
					}
	
					//3, more the better
					if (le.getPred1() > modelAccuracySummaryBean.getPred1()) {
						modelAccuracySummaryBean.setPred1Technique(le.getTechnique());
						modelAccuracySummaryBean.setPred1(le.getPred1());
					}
					
					//4, more the better
					if (le.getPred2() > modelAccuracySummaryBean.getPred2()) {
						modelAccuracySummaryBean.setPred2Technique(le.getTechnique());
						modelAccuracySummaryBean.setPred2(le.getPred2());
					}
					
					//5, less the better
					if (le.getSumAbsoluteResidualError() < modelAccuracySummaryBean.getSumAbsoluteResidualError()) {
						modelAccuracySummaryBean.setSumAbsoluteResidualErrorTechnique(le.getTechnique());
						modelAccuracySummaryBean.setSumAbsoluteResidualError(le.getSumAbsoluteResidualError());
					}
	
					//6, less the better
					if (le.getMedianAbsoluteResidualError() < modelAccuracySummaryBean.getMedianAbsoluteResidualError()) {
						modelAccuracySummaryBean.setMedianAbsoluteResidualErrorTechnique(le.getTechnique());
						modelAccuracySummaryBean.setMedianAbsoluteResidualError(le.getMedianAbsoluteResidualError());
					}
					
					//7, less the better
					if (le.getStdevAbsoluteResidualError() < modelAccuracySummaryBean.getStdevAbsoluteResidualError()) {
						modelAccuracySummaryBean.setStdevAbsoluteResidualError(le.getStdevAbsoluteResidualError());
						modelAccuracySummaryBean.setStdevAbsoluteResidualErrorTechnique(le.getTechnique());
					}
					
					//8, less the better
					if (le.getRmse() < modelAccuracySummaryBean.getRmse()) {
						modelAccuracySummaryBean.setRmse(le.getRmse());
						modelAccuracySummaryBean.setRmseTechnique(le.getTechnique());
					}
					
					//9, less the better
					if (le.getNrmse() < modelAccuracySummaryBean.getNrmse()) {
						modelAccuracySummaryBean.setNrmse(le.getNrmse());
						modelAccuracySummaryBean.setNrmseTechnique(le.getTechnique());
					} else if (le.getNrmse() == modelAccuracySummaryBean.getNrmse()) {
						System.out.println("Nrmse similar " + le.getTechnique() + "|" + modelAccuracySummaryBean.getNrmseTechnique());
						modelAccuracySummaryBean.setNrmseTechnique(
								modelAccuracySummaryBean.getNrmseTechnique() + ":" +
								le.getTechnique());
						
					}
					
					//10, less the better
					if (le.getRelativeAbsoluteError() < modelAccuracySummaryBean.getRelativeAbsoluteError()) {
						modelAccuracySummaryBean.setRelativeAbsoluteError(le.getRelativeAbsoluteError());
						modelAccuracySummaryBean.setRelativeAbsoluteErrorTechnique(le.getTechnique());
					} else if (le.getRelativeAbsoluteError() == modelAccuracySummaryBean.getRelativeAbsoluteError()) {
						//System.out.println("RAE similar " + le.getTechnique() + "|" + modelAccuracySummaryBean.getRelativeAbsoluteErrorTechnique());
						modelAccuracySummaryBean.setRelativeAbsoluteErrorTechnique(
								modelAccuracySummaryBean.getRelativeAbsoluteErrorTechnique() + ":" +
								le.getTechnique());
					}
					
					//11, less the better
					if (le.getRootOfrelativeSquareError() < modelAccuracySummaryBean.getRootOfrelativeSquareError()) {
						modelAccuracySummaryBean.setRootOfrelativeSquareError(le.getRootOfrelativeSquareError());
						modelAccuracySummaryBean.setRootOfrelativeSquareErrorTechnique(le.getTechnique());
					} else if (le.getRootOfrelativeSquareError() == modelAccuracySummaryBean.getRootOfrelativeSquareError()) {
						//System.out.println("SRAE similar " + le.getTechnique() + "|" + modelAccuracySummaryBean.getRootOfrelativeSquareErrorTechnique());
						modelAccuracySummaryBean.setRootOfrelativeSquareErrorTechnique(
								modelAccuracySummaryBean.getRootOfrelativeSquareErrorTechnique() + ":" +
								le.getTechnique());
						
					}
				}
				count++;
				
				System.out.println(le.toString());
			}
		
			if (debug.equals("true") == true) {
				System.out.println(modelAccuracySummaryBean.toString());
			}
			
			bw.write(modelAccuracySummaryBean.toString());
			bw.write("\n");

			bw.close();
			bw = null;
			fw.close();
			fw = null;

		} catch (IOException ioe) {
			System.out.println("IOException " + ioe.getMessage());
		}

		return;
		
	}
}
