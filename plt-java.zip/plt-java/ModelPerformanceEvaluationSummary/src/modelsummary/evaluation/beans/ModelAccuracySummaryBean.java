package modelsummary.evaluation.beans;

public class ModelAccuracySummaryBean {

	private String label;
	private String correlationTechnique;
	private String maxMagnitudeRelativeErrorTechnique;
	private String meanMagnitudeRelativeErrorTechnique;
	private String pred1Technique;
	private String pred2Technique;
	private String sumAbsoluteResidualErrorTechnique;
	private String medianAbsoluteResidualErrorTechnique;
	private String stdevAbsoluteResidualErrorTechnique;
	private String rmseTechnique;
	private String nrmseTechnique;
	private String relativeAbsoluteErrorTechnique;
	private String rootOfrelativeSquareErrorTechnique;
	
	
	private int    size;
	private double correlation;
	private double maxMagnitudeRelativeError;
	private double meanMagnitudeRelativeError;
	private double pred1;
	private double pred2;
	private double sumAbsoluteResidualError;
	private double medianAbsoluteResidualError;
	private double stdevAbsoluteResidualError;
	private double rmse;
	double nrmse;
	double relativeAbsoluteError;
	double rootOfrelativeSquareError;
	
	public ModelAccuracySummaryBean() {
		this.correlationTechnique = "";
		this.maxMagnitudeRelativeErrorTechnique = "";
		this.meanMagnitudeRelativeErrorTechnique = "";
		this.pred1Technique = "";
		this.pred2Technique = "";
		this.sumAbsoluteResidualErrorTechnique = "";
		this.medianAbsoluteResidualErrorTechnique = "";
		this.stdevAbsoluteResidualErrorTechnique = "";
		this.rmseTechnique = "";
		this.nrmseTechnique = "";
		this.relativeAbsoluteErrorTechnique = "";
		this.rootOfrelativeSquareErrorTechnique = "";

		this.size = 0;
		this.correlation = 0;
		this.maxMagnitudeRelativeError = 0;
		this.meanMagnitudeRelativeError = 0;
		this.pred1 = 0;
		this.pred2 = 0;
		this.sumAbsoluteResidualError = 0;
		this.medianAbsoluteResidualError = 0;
		this.stdevAbsoluteResidualError = 0;
		this.rmse = 0;
		this.nrmse = 0;
		this.relativeAbsoluteError = 0;
		this.rootOfrelativeSquareError = 0;
		
	}


	public String getMaxMagnitudeRelativeErrorTechnique() {
		return maxMagnitudeRelativeErrorTechnique;
	}


	public void setMaxMagnitudeRelativeErrorTechnique(String maxMagnitudeRelativeErrorTechnique) {
		this.maxMagnitudeRelativeErrorTechnique = maxMagnitudeRelativeErrorTechnique;
	}


	public String getMeanMagnitudeRelativeErrorTechnique() {
		return meanMagnitudeRelativeErrorTechnique;
	}


	public void setMeanMagnitudeRelativeErrorTechnique(String meanMagnitudeRelativeErrorTechnique) {
		this.meanMagnitudeRelativeErrorTechnique = meanMagnitudeRelativeErrorTechnique;
	}


	public String getPred1Technique() {
		return pred1Technique;
	}


	public void setPred1Technique(String pred1Technique) {
		this.pred1Technique = pred1Technique;
	}


	public String getPred2Technique() {
		return pred2Technique;
	}


	public void setPred2Technique(String pred2Technique) {
		this.pred2Technique = pred2Technique;
	}


	@Override
	public String toString() {
		return label + "|" +
			   size + "|" +
			   correlationTechnique + "|" +
			   correlation + "|" +
			   maxMagnitudeRelativeErrorTechnique + "|" +
			   maxMagnitudeRelativeError + "|" +
			   meanMagnitudeRelativeErrorTechnique + "|" +
			   meanMagnitudeRelativeError + "|" +
			   pred1Technique + "|" +
			   pred1 + "|" +
			   pred2Technique + "|" +
			   pred2 + "|" +
			   sumAbsoluteResidualErrorTechnique + "|" +
			   sumAbsoluteResidualError + "|" +
			   medianAbsoluteResidualErrorTechnique + "|" +
			   medianAbsoluteResidualError + "|" +
			   stdevAbsoluteResidualErrorTechnique + "|" +
			   stdevAbsoluteResidualError + "|" +
			   rmseTechnique + "|" +
			   rmse + "|" +
			   nrmseTechnique + "|" +
			   nrmse + "|" +
			   relativeAbsoluteErrorTechnique + "|" +
			   relativeAbsoluteError + "|" +
			   rootOfrelativeSquareErrorTechnique + "|" +
			   rootOfrelativeSquareError;
				
	}

	public String getCorrelationTechnique() {
		return correlationTechnique;
	}


	public void setCorrelationTechnique(String correlationTechnique) {
		this.correlationTechnique = correlationTechnique;
	}

	public String getSumAbsoluteResidualErrorTechnique() {
		return sumAbsoluteResidualErrorTechnique;
	}


	public void setSumAbsoluteResidualErrorTechnique(String sumAbsoluteResidualErrorTechnique) {
		this.sumAbsoluteResidualErrorTechnique = sumAbsoluteResidualErrorTechnique;
	}


	public String getMedianAbsoluteResidualErrorTechnique() {
		return medianAbsoluteResidualErrorTechnique;
	}


	public void setMedianAbsoluteResidualErrorTechnique(String medianAbsoluteResidualErrorTechnique) {
		this.medianAbsoluteResidualErrorTechnique = medianAbsoluteResidualErrorTechnique;
	}


	public String getStdevAbsoluteResidualErrorTechnique() {
		return stdevAbsoluteResidualErrorTechnique;
	}


	public void setStdevAbsoluteResidualErrorTechnique(String stdevAbsoluteResidualErrorTechnique) {
		this.stdevAbsoluteResidualErrorTechnique = stdevAbsoluteResidualErrorTechnique;
	}


	public String getRmseTechnique() {
		return rmseTechnique;
	}


	public void setRmseTechnique(String rmseTechnique) {
		this.rmseTechnique = rmseTechnique;
	}


	public String getNrmseTechnique() {
		return nrmseTechnique;
	}


	public void setNrmseTechnique(String nrmseTechnique) {
		this.nrmseTechnique = nrmseTechnique;
	}


	public String getRelativeAbsoluteErrorTechnique() {
		return relativeAbsoluteErrorTechnique;
	}


	public void setRelativeAbsoluteErrorTechnique(String relativeAbsoluteErrorTechnique) {
		this.relativeAbsoluteErrorTechnique = relativeAbsoluteErrorTechnique;
	}


	public String getRootOfrelativeSquareErrorTechnique() {
		return rootOfrelativeSquareErrorTechnique;
	}


	public void setRootOfrelativeSquareErrorTechnique(String rootOfrelativeSquareErrorTechnique) {
		this.rootOfrelativeSquareErrorTechnique = rootOfrelativeSquareErrorTechnique;
	}


	public String getLabel() {
		return label;
	}


	public void setLabel(String label) {
		this.label = label;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public double getCorrelation() {
		return correlation;
	}


	public void setCorrelation(double correlation) {
		this.correlation = correlation;
	}


	public double getMaxMagnitudeRelativeError() {
		return maxMagnitudeRelativeError;
	}


	public void setMaxMagnitudeRelativeError(double maxMagnitudeRelativeError) {
		this.maxMagnitudeRelativeError = maxMagnitudeRelativeError;
	}


	public double getMeanMagnitudeRelativeError() {
		return meanMagnitudeRelativeError;
	}


	public void setMeanMagnitudeRelativeError(double meanMagnitudeRelativeError) {
		this.meanMagnitudeRelativeError = meanMagnitudeRelativeError;
	}


	public double getPred1() {
		return pred1;
	}


	public void setPred1(double pred1) {
		this.pred1 = pred1;
	}


	public double getPred2() {
		return pred2;
	}


	public void setPred2(double pred2) {
		this.pred2 = pred2;
	}


	public double getSumAbsoluteResidualError() {
		return sumAbsoluteResidualError;
	}


	public void setSumAbsoluteResidualError(double sumAbsoluteResidualError) {
		this.sumAbsoluteResidualError = sumAbsoluteResidualError;
	}


	public double getMedianAbsoluteResidualError() {
		return medianAbsoluteResidualError;
	}


	public void setMedianAbsoluteResidualError(double medianAbsoluteResidualError) {
		this.medianAbsoluteResidualError = medianAbsoluteResidualError;
	}


	public double getStdevAbsoluteResidualError() {
		return stdevAbsoluteResidualError;
	}


	public void setStdevAbsoluteResidualError(double stdevAbsoluteResidualError) {
		this.stdevAbsoluteResidualError = stdevAbsoluteResidualError;
	}


	public double getRmse() {
		return rmse;
	}


	public void setRmse(double rmse) {
		this.rmse = rmse;
	}


	public double getNrmse() {
		return nrmse;
	}


	public void setNrmse(double nrmse) {
		this.nrmse = nrmse;
	}


	public double getRelativeAbsoluteError() {
		return relativeAbsoluteError;
	}


	public void setRelativeAbsoluteError(double relativeAbsoluteError) {
		this.relativeAbsoluteError = relativeAbsoluteError;
	}


	public double getRootOfrelativeSquareError() {
		return rootOfrelativeSquareError;
	}


	public void setRootOfrelativeSquareError(double rootOfrelativeSquareError) {
		this.rootOfrelativeSquareError = rootOfrelativeSquareError;
	}
	

}
