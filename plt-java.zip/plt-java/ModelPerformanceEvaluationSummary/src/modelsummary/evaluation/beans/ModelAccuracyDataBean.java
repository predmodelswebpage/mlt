package modelsummary.evaluation.beans;

public class ModelAccuracyDataBean {
	
	public static final int  LABEL = 0;
	public static final int  TECHNIQUE = 1;
	public static final int  SIZE = 2;
	public static final int  ETIME = 3;
	public static final int  CORRELATION = 4;
	public static final int  MAXMAGNITUDERELATIVEERROR = 5;
	public static final int  MEANMAGNITUDERELATIVEERROR = 6;
	public static final int  PRED1 = 7;
	public static final int  PRED2 = 8;
	public static final int  SUMABSOLUTERESIDUALERROR = 9;
	public static final int  MEDIANABSOLUTERESIDUALERROR = 10;
	public static final int  STDEVABSOLUTERESIDUALERROR = 11;
	public static final int  RMSE = 12;
	public static final int  NRMSE = 13;
	public static final int  RELATIVEABSOLUTEERROR = 14;
	public static final int  ROOTOFRELATIVESQUAREERROR = 15;
	
	private String label;
	private String technique;

	private int    size;
	private double correlation;
	private double maxMagnitudeRelativeError;
	private double meanMagnitudeRelativeError;
	private double pred1;
	private double pred2;
	private double sumAbsoluteResidualError;
	private double medianAbsoluteResidualError;
	private double stdevAbsoluteResidualError;
	private double rmse;
	private double nrmse;
	private double relativeAbsoluteError;
	private double rootOfrelativeSquareError;
	
	public ModelAccuracyDataBean(String label, String technique, int size, double correlation, double maxMagnitudeRelativeError,
			double meanMagnitudeRelativeError, double pred1, double pred2, double sumAbsoluteResidualError,
			double medianAbsoluteResidualError, double stdevAbsoluteResidualError, double rmse, double nrmse,
			double relativeAbsoluteError, double rootOfrelativeSquareError) {
		super();
		this.label = label;
		this.technique = technique;
		this.size = size;
		this.correlation = correlation;
		this.maxMagnitudeRelativeError = maxMagnitudeRelativeError;
		this.meanMagnitudeRelativeError = meanMagnitudeRelativeError;
		this.pred1 = pred1;
		this.pred2 = pred2;
		this.sumAbsoluteResidualError = sumAbsoluteResidualError;
		this.medianAbsoluteResidualError = medianAbsoluteResidualError;
		this.stdevAbsoluteResidualError = stdevAbsoluteResidualError;
		this.rmse = rmse;
		this.nrmse = nrmse;
		this.relativeAbsoluteError = relativeAbsoluteError;
		this.rootOfrelativeSquareError = rootOfrelativeSquareError;
	}

	public double getCorrelation() {
		return correlation;
	}

	public void setCorrelation(double correlation) {
		this.correlation = correlation;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public String getTechnique() {
		return technique;
	}
	
	public void setTechnique(String technique) {
		this.technique = technique;
	}
	
	public int getSize() {
		return size;
	}
	
	public void setSize(int size) {
		this.size = size;
	}
	
	public double getMaxMagnitudeRelativeError() {
		return maxMagnitudeRelativeError;
	}
	
	public void setMaxMagnitudeRelativeError(double maxMagnitudeRelativeError) {
		this.maxMagnitudeRelativeError = maxMagnitudeRelativeError;
	}
	
	public double getMeanMagnitudeRelativeError() {
		return meanMagnitudeRelativeError;
	}
	
	public void setMeanMagnitudeRelativeError(double meanMagnitudeRelativeError) {
		this.meanMagnitudeRelativeError = meanMagnitudeRelativeError;
	}
	
	public double getPred1() {
		return pred1;
	}
	
	public void setPred1(double pred1) {
		this.pred1 = pred1;
	}
	
	public double getPred2() {
		return pred2;
	}
	
	public void setPred2(double pred2) {
		this.pred2 = pred2;
	}
	
	public double getSumAbsoluteResidualError() {
		return sumAbsoluteResidualError;
	}
	
	public void setSumAbsoluteResidualError(double sumAbsoluteResidualError) {
		this.sumAbsoluteResidualError = sumAbsoluteResidualError;
	}
	
	public double getMedianAbsoluteResidualError() {
		return medianAbsoluteResidualError;
	}
	
	public void setMedianAbsoluteResidualError(double medianAbsoluteResidualError) {
		this.medianAbsoluteResidualError = medianAbsoluteResidualError;
	}
	
	public double getStdevAbsoluteResidualError() {
		return stdevAbsoluteResidualError;
	}
	
	public void setStdevAbsoluteResidualError(double stdevAbsoluteResidualError) {
		this.stdevAbsoluteResidualError = stdevAbsoluteResidualError;
	}
	
	public double getRmse() {
		return rmse;
	}
	
	public void setRmse(double rmse) {
		this.rmse = rmse;
	}
	
	public double getNrmse() {
		return nrmse;
	}
	
	public void setNrmse(double nrmse) {
		this.nrmse = nrmse;
	}
	
	public double getRelativeAbsoluteError() {
		return relativeAbsoluteError;
	}
	
	public void setRelativeAbsoluteError(double relativeAbsoluteError) {
		this.relativeAbsoluteError = relativeAbsoluteError;
	}
	
	public double getRootOfrelativeSquareError() {
		return rootOfrelativeSquareError;
	}
	
	public void setRootOfrelativeSquareError(double rootOfrelativeSquareError) {
		this.rootOfrelativeSquareError = rootOfrelativeSquareError;
	}

	public String toString() {
		return "ModelAccuracyDataBean [label=" + label + ", technique=" + technique + ", size=" + size 
				+ ", correlation=" + correlation
				+ ", maxMagnitudeRelativeError=" + maxMagnitudeRelativeError + ", meanMagnitudeRelativeError="
				+ meanMagnitudeRelativeError + ", pred1=" + pred1 + ", pred2=" + pred2 + ", sumAbsoluteResidualError="
				+ sumAbsoluteResidualError + ", medianAbsoluteResidualError=" + medianAbsoluteResidualError
				+ ", stdevAbsoluteResidualError=" + stdevAbsoluteResidualError + ", rmse=" + rmse + ", nrmse=" + nrmse
				+ ", relativeAbsoluteError=" + relativeAbsoluteError + ", rootOfrelativeSquareError="
				+ rootOfrelativeSquareError + "]";
	}
	
}
